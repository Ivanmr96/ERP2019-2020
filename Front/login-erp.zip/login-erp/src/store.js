import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'
//Axios es una libreria para peticiones AJAX en HTTP
Vue.use(Vuex)

//Store es un contenedor de vuex para manejar el estado de la aplicacion
export default new Vuex.Store({
    state: {
        loggingIn: false,
        loginError: null,
        loginSuccessful: false
    },
    mutations: {
        loginStart: state => state.loggingIn = true,
        loginStop: (state, errorMessage) => {
            state.loggingIn = false;
            state.loginError = errorMessage;
            state.loginSuccessful = !errorMessage;
        }
    },
    actions: {
        doLogin({ commit }, loginData) {
            commit('loginStart');
            //Para la api
            axios.post('http://localhost:8080/', {
                ...loginData
            })
                .then(() => {
                    commit('loginStop', null)
                })
                .catch(error => {
                    commit('loginStop', error.response.data.error)
                })
        }
    }
})